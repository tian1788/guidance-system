<?php
include "../config/db.php";

/* ADD RECORD */

if(isset($_POST['add'])){

$name = $_POST['student_name'];
$concern = $_POST['concern'];
$action = $_POST['action_taken'];
$date = $_POST['date_recorded'];

$conn->query("INSERT INTO guidance(student_name,concern,action_taken,date_recorded)
VALUES('$name','$concern','$action','$date')");
}

/* DELETE */

if(isset($_GET['delete'])){
$id=$_GET['delete'];
$conn->query("DELETE FROM guidance WHERE id=$id");
}

/* FETCH DATA */

$result = $conn->query("SELECT * FROM guidance");

?>

<link rel="stylesheet" href="../css/style.css">

<div class="sidebar">

<h2>Guidance</h2>

<a href="dashboard.php">Dashboard</a>
<a href="students.php">Student Info</a>
<a href="counseling.php">Academic Counseling</a>
<a href="guidance.php">Guidance Records</a>
<a href="crisis.php">Crisis Intervention</a>
<a href="survey.php">Survey & Feedback</a>
<a href="../logout.php">Logout</a>

</div>

<div class="main">

<h2>Guidance Records</h2>

<!-- ADD GUIDANCE RECORD -->

<div class="form-box">

<form method="POST">

<input name="student_name" placeholder="Student Name" required>

<textarea name="concern" placeholder="Student Concern" required></textarea>

<textarea name="action_taken" placeholder="Action Taken" required></textarea>

<label>Date</label>
<input type="date" name="date_recorded" required>

<button name="add">Add Record</button>

</form>

</div>

<!-- TABLE -->

<table>

<tr>
<th>Student</th>
<th>Concern</th>
<th>Action Taken</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['student_name']; ?></td>
<td><?php echo $row['concern']; ?></td>
<td><?php echo $row['action_taken']; ?></td>
<td><?php echo $row['date_recorded']; ?></td>

<td>

<a href="guidance_edit.php?id=<?php echo $row['id']; ?>">Edit</a> |

<a href="guidance.php?delete=<?php echo $row['id']; ?>"
onclick="return confirm('Delete this record?')">Delete</a>

</td>

</tr>

<?php } ?>

</table>

</div>