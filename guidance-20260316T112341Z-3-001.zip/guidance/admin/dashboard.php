<?php
session_start();
include "../config/db.php";

// Total students
$totalStudents = $conn->query("SELECT * FROM users WHERE role='student'")->num_rows;

// Counseling requests
$totalCounseling = $conn->query("SELECT * FROM counseling")->num_rows;
$pendingCounseling = $conn->query("SELECT * FROM counseling WHERE status='Pending'")->num_rows;

// Guidance records
$totalGuidance = $conn->query("SELECT * FROM guidance")->num_rows;
$recentGuidance = $conn->query("SELECT * FROM guidance WHERE date_recorded >= CURDATE() - INTERVAL 7 DAY")->num_rows;

// Survey feedback
$totalSurvey = $conn->query("SELECT * FROM survey")->num_rows;
$newSurvey = $conn->query("SELECT * FROM survey WHERE date_submitted >= CURDATE() - INTERVAL 7 DAY")->num_rows;

// Crisis reports
$totalCrisis = $conn->query("SELECT * FROM crisis")->num_rows;
$newCrisis = $conn->query("SELECT * FROM crisis WHERE date_reported >= CURDATE() - INTERVAL 7 DAY")->num_rows;
?>

<link rel="stylesheet" href="../css/style.css">

<div class="sidebar">
<h2>Admin</h2>
<a href="dashboard.php">Dashboard</a>
<a href="students.php">Student Info</a>
<a href="counseling.php">Academic Counseling</a>
<a href="guidance.php">Guidance Records</a>
<a href="crisis.php">Crisis Intervention</a>
<a href="survey.php">Survey & Feedback</a>
<a href="../logout.php">Logout</a>
</div>

<div class="main">
<h1>Guidance Management Dashboard</h1>
<p>Welcome, Admin! Here's a quick overview with notifications.</p>

<div class="cards">

<!-- Total Students -->
<div class="card">
    <h3>Total Students</h3>
    <p><?php echo $totalStudents; ?></p>
</div>

<!-- Counseling Requests -->
<div class="card">
    <h3>Counseling Requests</h3>
    <p><?php echo $totalCounseling; ?></p>
    <?php if($pendingCounseling > 0): ?>
        <span class="notification"><?php echo $pendingCounseling; ?> Pending</span>
    <?php endif; ?>
</div>

<!-- Guidance Records -->
<div class="card">
    <h3>Guidance Records</h3>
    <p><?php echo $totalGuidance; ?></p>
    <?php if($recentGuidance > 0): ?>
        <span class="notification"><?php echo $recentGuidance; ?> New</span>
    <?php endif; ?>
</div>

<!-- Survey Feedback -->
<div class="card">
    <h3>Survey Feedback</h3>
    <p><?php echo $totalSurvey; ?></p>
    <?php if($newSurvey > 0): ?>
        <span class="notification"><?php echo $newSurvey; ?> New</span>
    <?php endif; ?>
</div>

<!-- Crisis Reports -->
<div class="card">
    <h3>Crisis Reports</h3>
    <p><?php echo $totalCrisis; ?></p>
    <?php if($newCrisis > 0): ?>
        <span class="notification"><?php echo $newCrisis; ?> New</span>
    <?php endif; ?>
</div>

</div>
</div>