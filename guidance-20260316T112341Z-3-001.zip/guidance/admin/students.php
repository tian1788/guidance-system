<?php
include "../config/db.php";

/* ADD STUDENT */

if(isset($_POST['add'])){

$student_id=$_POST['student_id'];
$name=$_POST['name'];
$course=$_POST['course'];
$year=$_POST['year'];

$conn->query("INSERT INTO students(student_id,name,course,year_level)
VALUES('$student_id','$name','$course','$year')");
}

/* DELETE STUDENT */

if(isset($_GET['delete'])){
$id=$_GET['delete'];
$conn->query("DELETE FROM students WHERE id=$id");
}

/* GET STUDENTS */

$result=$conn->query("SELECT * FROM students");

?>

<link rel="stylesheet" href="../css/style.css">

<div class="sidebar">

<h2>Admin</h2>

<a href="dashboard.php">Dashboard</a>
<a href="students.php">Student Info</a>
<a href="counseling.php">Academic Counseling</a>
<a href="guidance.php">Guidance Records</a>
<a href="crisis.php">Crisis Intervention</a>
<a href="survey.php">Survey & Feedback</a>
<a href="../logout.php">Logout</a>

</div>

<div class="main">

<h2>Student Information</h2>

<!-- ADD STUDENT -->

<div class="form-box">

<form method="POST">

<input name="student_id" placeholder="Student ID" required>

<input name="name" placeholder="Student Name" required>

<input name="course" placeholder="Course" required>

<input name="year" placeholder="Year Level" required>

<button name="add">Add Student</button>

</form>

</div>

<!-- STUDENT TABLE -->

<table>

<tr>
<th>ID</th>
<th>Name</th>
<th>Course</th>
<th>Year</th>
<th>Action</th>
</tr>

<?php
while($row=$result->fetch_assoc()){
?>

<tr>

<td><?php echo $row['student_id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['course']; ?></td>
<td><?php echo $row['year_level']; ?></td>

<td>

<a href="edit_student.php?id=<?php echo $row['id']; ?>">Edit</a> |

<a href="students.php?delete=<?php echo $row['id']; ?>"
onclick="return confirm('Delete this student?')">Delete</a>

</td>

</tr>

<?php } ?>

</table>

</div>