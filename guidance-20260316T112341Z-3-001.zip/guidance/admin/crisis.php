<?php
include "../config/db.php";

/* ADD CRISIS CASE */

if(isset($_POST['add'])){

$name = $_POST['student_name'];
$incident = $_POST['incident'];
$action = $_POST['action_taken'];
$date = $_POST['date_reported'];

$conn->query("INSERT INTO crisis(student_name,incident,action_taken,date_reported)
VALUES('$name','$incident','$action','$date')");
}

/* DELETE CASE */

if(isset($_GET['delete'])){
$id=$_GET['delete'];
$conn->query("DELETE FROM crisis WHERE id=$id");
}

/* FETCH DATA */

$result = $conn->query("SELECT * FROM crisis");
?>

<link rel="stylesheet" href="../css/style.css">

<div class="sidebar">

<h2>Guidance</h2>

<a href="dashboard.php">Dashboard</a>
<a href="students.php">Student Info</a>
<a href="counseling.php">Academic Counseling</a>
<a href="guidance.php">Guidance Records</a>
<a href="crisis.php">Crisis Intervention</a>
<a href="survey.php">Survey & Feedback</a>
<a href="../logout.php">Logout</a>

</div>

<div class="main">

<h2>Crisis Intervention</h2>

<!-- ADD CASE FORM -->

<div class="form-box">

<form method="POST">

<input name="student_name" placeholder="Student Name" required>

<textarea name="incident" placeholder="Incident Details" required></textarea>

<textarea name="action_taken" placeholder="Action Taken" required></textarea>

<label>Date Reported</label>
<input type="date" name="date_reported" required>

<button name="add">Add Case</button>

</form>

</div>

<!-- TABLE -->

<table>

<tr>
<th>Student</th>
<th>Incident</th>
<th>Action Taken</th>
<th>Date Reported</th>
<th>Action</th>
</tr>

<?php while($row=$result->fetch_assoc()){ ?>

<tr>

<td><?php echo $row['student_name']; ?></td>
<td><?php echo $row['incident']; ?></td>
<td><?php echo $row['action_taken']; ?></td>
<td><?php echo $row['date_reported']; ?></td>

<td>
<a href="crisis_edit.php?id=<?php echo $row['id']; ?>">Edit</a> |
<a href="crisis.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Delete this case?')">Delete</a>
</td>

</tr>

<?php } ?>

</table>

</div>