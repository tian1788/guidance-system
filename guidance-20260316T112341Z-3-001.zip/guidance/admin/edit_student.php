<?php
include "../config/db.php";

$id=$_GET['id'];

$result=$conn->query("SELECT * FROM students WHERE id=$id");
$row=$result->fetch_assoc();

if(isset($_POST['update'])){

$student_id=$_POST['student_id'];
$name=$_POST['name'];
$course=$_POST['course'];
$year=$_POST['year'];

$conn->query("UPDATE students SET
student_id='$student_id',
name='$name',
course='$course',
year_level='$year'
WHERE id=$id");

header("Location: students.php");

}
?>

<link rel="stylesheet" href="../css/style.css">

<div class="main">

<h2>Edit Student</h2>

<div class="form-box">

<form method="POST">

<input name="student_id" value="<?php echo $row['student_id']; ?>">

<input name="name" value="<?php echo $row['name']; ?>">

<input name="course" value="<?php echo $row['course']; ?>">

<input name="year" value="<?php echo $row['year_level']; ?>">

<button name="update">Update Student</button>

</form>

</div>

</div>