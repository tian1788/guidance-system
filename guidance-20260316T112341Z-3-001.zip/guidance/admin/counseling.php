<?php
include "../config/db.php";

/* SEND REPLY */
if(isset($_POST['send_reply'])){
    $id = $_POST['id'];
    $reply = $_POST['reply'];
    $conn->query("UPDATE counseling SET reply='$reply', status='Replied' WHERE id=$id");
}

/* ADD COUNSELING */
if(isset($_POST['add'])){
    $name = $_POST['student_name'];
    $issue = $_POST['issue'];
    $date = $_POST['schedule'];
    $status = "Pending";
    $conn->query("INSERT INTO counseling(student_name,issue,schedule_date,status)
    VALUES('$name','$issue','$date','$status')");
}

/* DELETE */
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $conn->query("DELETE FROM counseling WHERE id=$id");
}

/* UPDATE STATUS */
if(isset($_POST['update_status'])){
    $id = $_POST['id'];
    $status = $_POST['status'];
    $conn->query("UPDATE counseling SET status='$status' WHERE id=$id");
}

/* GET DATA */
$result = $conn->query("SELECT * FROM counseling ORDER BY id DESC");
?>
<link rel="stylesheet" href="../css/style.css">
<div class="sidebar">
<h2>Admin</h2>
<a href="dashboard.php">Dashboard</a>
<a href="students.php">Student Info</a>
<a href="counseling.php">Academic Counseling</a>
<a href="guidance.php">Guidance Records</a>
<a href="crisis.php">Crisis Intervention</a>
<a href="survey.php">Survey & Feedback</a>
<a href="../logout.php">Logout</a>
</div>
<div class="main">
<h1>Academic Counseling</h1>

<!-- ADD COUNSELING -->
<div class="form-box">
<form method="POST">
<input name="student_name" placeholder="Student Name" required>
<textarea name="issue" placeholder="Counseling Issue" required></textarea>
<label>Schedule Date</label>
<input type="date" name="schedule" required>
<button name="add">Add Counseling</button>
</form>
</div>

<!-- COUNSELING TABLE -->
<div class="records-table">
<table>
<tr>
<th>Student</th>
<th>Issue</th>
<th>Schedule</th>
<th>Status</th>
<th>Reply</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()){ ?>
<tr>
<td><?php echo $row['student_name']; ?></td>
<td><?php echo $row['issue']; ?></td>
<td><?php echo $row['schedule_date']; ?></td>

<td>
<form method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
<select name="status">
<option <?php if($row['status']=="Pending") echo "selected"; ?>>Pending</option>
<option <?php if($row['status']=="Scheduled") echo "selected"; ?>>Scheduled</option>
<option <?php if($row['status']=="Completed") echo "selected"; ?>>Completed</option>
<option <?php if($row['status']=="Replied") echo "selected"; ?>>Replied</option>
</select>
<button name="update_status">Update</button>
</form>
</td>

<td><?php echo $row['reply'] ?? "No reply yet"; ?></td>

<td>
<form method="POST">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
<textarea name="reply" placeholder="Write reply..."></textarea>
<button name="send_reply">Send Reply</button>
</form>
<a href="counseling.php?delete=<?php echo $row['id']; ?>" onclick="return confirm('Delete this record?')">Delete</a>
</td>
</tr>
<?php } ?>
</table>
</div>
</div>