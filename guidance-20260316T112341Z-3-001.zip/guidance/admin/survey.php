<?php
include "../config/db.php";

$result = $conn->query("SELECT * FROM survey ORDER BY date_submitted DESC");
?>

<link rel="stylesheet" href="../css/style.css">

<div class="sidebar">

<h2>Guidance</h2>

<a href="dashboard.php">Dashboard</a>
<a href="students.php">Student Info</a>
<a href="counseling.php">Academic Counseling</a>
<a href="guidance.php">Guidance Records</a>
<a href="crisis.php">Crisis Intervention</a>
<a href="survey.php">Survey & Feedback</a>
<a href="../logout.php">Logout</a>

</div>

<div class="main">

<h2>Survey & Feedback</h2>


<table>
<tr>
<th>Date Submitted</th>
<th>Student Name</th>
<th>Feedback</th>
<th>Rating</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
               
<td><?php echo $row['date_submitted']; ?></td>
<td><?php echo $row['student_name']; ?></td>
<td><?php echo $row['feedback']; ?></td>
<td><?php echo $row['rating']; ?></td>
<td><?php echo $row['status']; ?></td>
<td>
<?php if($row['status']=='Pending'): ?>
    <a href="survey_review.php?id=<?php echo $row['id']; ?>">Mark as Reviewed</a>
<?php else: ?>
    Reviewed by <?php echo $row['reviewed_by'] ?? 'Admin'; ?>
<?php endif; ?>
|
<a href="survey_delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this survey?');">Delete</a>
</td>
</tr>
<?php endwhile; ?>
</table>